# 📚 Day 01 to Day 19 - AI Learning Summary

This folder includes all my learnings, code, and projects from Day 01 to 19 of my 131-day AI learning journey.

## 🧠 Topics Covered
- Python (basics to advanced)
- File I/O and CSV
- Numpy and Pandas
- Data cleaning & visualization
- Matplotlib & Seaborn
- Intro to Machine Learning (Day 18-19)

Each day includes:
- Code notebook (`.ipynb`)
- Notes (`.md`)
- Any mini-projects (in `mini-projects/`)
