# Day 14 - Notes

Summary of what I learned on Day 14.