# Day 07 - Notes

Summary of what I learned on Day 07.