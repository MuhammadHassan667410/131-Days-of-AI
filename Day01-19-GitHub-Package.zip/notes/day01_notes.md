# Day 01 - Notes

Summary of what I learned on Day 01.