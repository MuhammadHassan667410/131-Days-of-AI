# Day 18 - Notes

Summary of what I learned on Day 18.